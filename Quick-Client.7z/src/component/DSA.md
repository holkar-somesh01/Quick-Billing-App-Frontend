leetcode 50

array, object

Big O Notaion
