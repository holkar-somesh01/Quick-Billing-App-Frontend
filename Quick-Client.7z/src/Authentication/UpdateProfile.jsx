import React from "react";
import SubNav from "../screens/SubNav";

const UpdateProfile = () => {
  return (
    <>
      <div className="h-screen bg-slate-100">
        <div>
          <SubNav />
        </div>
        <div></div>
      </div>
    </>
  );
};

export default UpdateProfile;
